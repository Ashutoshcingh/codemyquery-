from flask import Flask, render_template, request
from werkzeug import secure_filename
from flaskext.mysql import MySQL
mysql=MySQL()

app = Flask(__name__)
app.config['MYSQL_DATABASE_USER']='root'
app.config['MYSQL_DATABASE_PASSWORD']='12345'
app.config['MYSQL_DATABASE_DB']='cancer_prediction'
app.config['MYSQL_DATABASE_host']='localhost'
mysql.init_app(app)

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/registration')
def registration():
    return render_template('new_reg.html')

@app.route('/patient')
def patient():
    return render_template('patient_login.html')

@app.route('/doctor')
def doctor():
    return render_template('doctor_login.html')

@app.route('/generate_patient_report/')
def generate_patient_report():
    id = request.args.get('patient_id', default='', type=str)
    return render_template('generate_report.html',id=id)

@app.route('/create_account',methods=['GET','POST'])
def create_account():
    if request.method == 'POST':
        name = request.form['name']
        mobileno = request.form['mobileno']
        email = request.form['email']
        password = request.form['password']
        connection = mysql.get_db()
        cursor = connection.cursor()
        query="INSERT INTO users(name,mobile,email,password) VALUES(%s,%s,%s,%s)"
        cursor.execute(query,(name,mobileno,email,password))
        connection.commit()
        return render_template('new_reg.html',msg="User Registered Successfully")
    else:
        return("Unable to Register Now")

@app.route('/check_doctor_login',methods=['GET','POST'])
def check_doctor_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        connection = mysql.get_db()
        cursor = connection.cursor()
        new_value= cursor.execute("SELECT * FROM doctors where username = %s and password=%s",(username,password))
        if new_value> 0:
            cursor.execute("SELECT name,mobile,id FROM users")
            data = cursor.fetchall()
            return render_template('patient_list.html',data=data)
        else:
            return render_template('doctor_login.html',msg="Invalid Credentials")

@app.route('/preview_report',methods=['GET','POST'])
def preview_report():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        connection = mysql.get_db()
        cursor = connection.cursor()
        new_value= cursor.execute("SELECT * FROM users where email = %s and password=%s",(email,password))
        if new_value> 0:
            cursor.execute("SELECT * FROM users WHERE email=%s",(email))
            data = cursor.fetchall()
            for item in data :
                id=item[4]
            cursor.execute("SELECT * FROM report WHERE user_id=%s",(id))
            report_data = cursor.fetchall()
            return render_template('preview_report.html',data=data,report_data=report_data)
        else:
            return render_template('patient_login.html',msg="Invalid Credentials")

@app.route('/uploader',methods=['GET','POST'])
def uploader():
    if request.method == 'POST':
        f = request.files['file']
        patient_id = request.form['patient_id']
        f.save(secure_filename(f.filename))
        import pandas as pd
        from sklearn.model_selection import train_test_split
        from sklearn.linear_model import LogisticRegression
        from sklearn import metrics
        ##import the data file
        data=pd.read_csv("C:\\Users\\Ashutosh Singh\\Desktop\\Anshika\\data.csv")
        data1=pd.read_csv(f.filename)
        ##input features(independent variable or extracted image features)
        x=data.iloc[:,2:31].values
        y=data.iloc[:,1].values
        x_t=data1.iloc[:,2:31].values
        ##split test and train data set
        x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.30,random_state=0)
        reg=LogisticRegression()


        ##fitting the model
        reg.fit(x_train,y_train)
        ##making prediction
        y_pred=reg.predict(x_test)
        y_t=reg.predict(x_t)
        ##checking performance by using confusion matrix
        cnf_matrix = metrics.confusion_matrix(y_test, y_pred)
        cnf_matrix


        for i in range(len(x_t)):
            print("Predicted=%s" % (y_t[i]))

        per =str(metrics.accuracy_score(y_test, y_pred)*100)
        res = y_t[0]
        connection = mysql.get_db()
        cursor = connection.cursor()
        query="INSERT INTO report(user_id,accuracy,result) VALUES(%s,%s,%s)"
        cursor.execute(query,(patient_id,per,res))
        connection.commit()


        return render_template('generate_report.html',accuracy=str(metrics.accuracy_score(y_test, y_pred)*100),result=y_t,message="Report Generated Successfully")



if __name__ == '__main__':
    app.run(debug = True)
