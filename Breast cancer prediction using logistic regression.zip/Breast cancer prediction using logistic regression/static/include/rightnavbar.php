<div class="aside-nav">
   <ul>
      <li><a>This is a college Project for Prediction of cancer using Machine Learning</a></li>

   </ul>
</div>
