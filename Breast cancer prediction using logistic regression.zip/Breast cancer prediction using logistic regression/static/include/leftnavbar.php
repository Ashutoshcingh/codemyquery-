<aside class="s-12 l-3">
   <h3>Navigation</h3>
   <div class="aside-nav">
      <ul>
         <li><a>Home</a></li>
         <li><a href="new_reg.php">New Registration</a></li>
         <li>
            <a>Login</a>
            <ul>
               <li><a>Patient</a></li>
               <li><a>Doctor</a></li>
            </ul>
         </li>

      </ul>
   </div>
</aside>
